close all, clear all;

%definiranje simbolickih varijabli

z = sym('z');
q0 = sym('q0');
q1 = sym('q1');
q2 = sym('q2');
q3 = sym('q3');
q4 = sym('q4');

p = 3;

Q = q0+q1*z^(-1)+q2*z^(-2)+q3*z^(-3)+q4*z^(-4);
B = (1+z^(-1))^(2*p);

P0 = collect(B*Q,z);

%Kada ispisemo P0 dobijemo (q0*z^10 + (q1 + 6*q0)*z^9 + (6*q1 + q2 + 15*q0)*z^8 + (15*q1 + 6*q2 + q3 + 20*q0)*z^7 + (20*q1 + 15*q2 + 6*q3 + q4 + 15*q0)*z^6 + (15*q1 + 20*q2 + 15*q3 + 6*q4 + 6*qo)*z^5 + (6*q1 + 15*q2 + 20*q3 + 15*q4 + qo)*z^4 + (q1 + 6*q2 + 15*q3 + 20*q4)*z^3 + (q2 + 6*q3 + 15*q4)*z^2 + (q3 + 6*q4)*z + q4)/z^10
%Vidimo da njegove potencije idu od z^0 do z^-10
%da bi dobili simetriju, potencije moraju ici od z^-5 do z^5

P = P0*z^5;

%Iz uvjeta (5) proizlazi da P(z) uz sve neparne potencije od z ima
%koeficijente jednake 0, osim uz z^-1, gdje je koeficijent jednak 1

% Jednadzbe:

% (q0*z^10 + (6*q0 + q1)*z^9 + (15*q0 + 6*q1 + q2)*z^8 + (20*q0 + 15*q1 + 6*q2 + q3)*z^7 + (15*q0 + 20*q1 + 15*q2 + 6*q3 + q4)*z^6 + (6*q0 + 15*q1 + 20*q2 + 15*q3 + 6*q4)*z^5 + (q0 + 6*q1 + 15*q2 + 20*q3 + 15*q4)*z^4 + (q1 + 6*q2 + 15*q3 + 20*q4)*z^3 + (q2 + 6*q3 + 15*q4)*z^2 + (q3 + 6*q4)*z + q4)/z^5

% 6*q0 + q1 = 0
% 20*q0 + 15*q1 + 6*q2 + q3 = 0
% 6*q0 + 15*q1 + 20*q2 + 15*q3 + 6*q4 = 1 --> 6*q0 + 15*q1 + 20*q2 + 15*q3 + 6*q4 -1 = 0
% q1 + 6*q2 + 15*q3 + 20*q4 = 0
% q3 + 6*q4 = 0

p_4 = 6*q0 + q1;
p_2 = 20*q0 + 15*q1 + 6*q2 + q3;
p0 = 6*q0 + 15*q1 + 20*q2 + 15*q3 + 6*q4 -1;
p2 = q1 + 6*q2 + 15*q3 + 20*q4;
p4 = q3 + 6*q4;

[q0, q1, q2, q3, q4] = solve(p_4, p_2, p0, p2, p4);

sQ = solve(eval(Q));
Qr = eval(sQ);

%faktorizacija 9

Q12 = real(sQ(3));
Q22 = real(sQ(1));

H0 = collect((1+z^-1)*Q12);
F0 = collect((1+z^-1)^5*Q22);

% 7 predavanje, slide 12 --> H1(z) = F0(-z), F1(z) = -H0(-z)
%
% ****************
% TEST:
% g = -z;
% h = 32*z+17-z^3;
% f = compose(h,g);
% ****************
syms w; %omega
g = -z;
h = exp(i*w);

H1 = compose(F0,g);
H1_e = compose(H1,h);
F1 = -1*compose(H0,g);
F1_e = compose(F1,h);

H0_e = compose(H0,h);

figure;
ezplot(abs(H0_e), [-pi,pi]);
title('|H0|');

figure;
ezplot(abs(H1_e), [-pi,pi]);
title('|H1|');

figure;
ezplot(abs(H0_e)^2+abs(H1_e)^2, [-pi,pi]);
title('|H0|^2+|H1|^2');


h0 = sym2poly(H0*z^5);
h1 = sym2poly(eval(H1*z^5));
figure
subplot(2,1,1)
stem(h0)
title('Impulsni odziv h0')

subplot(2,1,2)
stem(h1)
title('Impulsni odziv h1')
